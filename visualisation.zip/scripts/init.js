// Initializing stuff

$('.nav-tabs > li > a').click(function () {
    $(this).tab('show');
});