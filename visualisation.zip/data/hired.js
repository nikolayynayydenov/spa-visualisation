let hired = [
    {
        "activity": "Селско, горско и рибно стопанство",
        "all": "71101",
        "publicSector": "11925",
        "privateSector": "59176"
    },
    {
        "activity": "Добивна промишленост",
        "all": "21219",
        "publicSector": "7344",
        "privateSector": "13875"
    },
    {
        "activity": "Преработваща промишленост",
        "all": "519790",
        "publicSector": "7073",
        "privateSector": "512717"
    },
    {
        "activity": "Производство и разпределение на електрическа и топлинна енергия и на газообразни горива ",
        "all": "30252",
        "publicSector": "14677",
        "privateSector": "15575"
    },
    {
        "activity": "Доставяне на води;канализационни услуги,управление на отпадъци и възстановяване",
        "all": "36904",
        "publicSector": "22433",
        "privateSector": "14471"
    },
    {
        "activity": "Строителство",
        "all": "131140",
        "publicSector": "2126",
        "privateSector": "129014"
    },
    {
        "activity": "Търговия; ремонт на автомобили и мотоциклети",
        "all": "377445",
        "publicSector": "434",
        "privateSector": "377011"
    },
    {
        "activity": "Транспорт, складиране и пощи",
        "all": "149981",
        "publicSector": "47645",
        "privateSector": "102336"
    },
    {
        "activity": "Хотелиерство и ресторантьорство",
        "all": "120168",
        "publicSector": "4324",
        "privateSector": "115844"
    },
    {
        "activity": "Създаване и разпространение на информация и творчески продукти; далекосъобщения",
        "all": "95447",
        "publicSector": "3722",
        "privateSector": "91725"
    },
    {
        "activity": "Финансови и застрахователни дейности",
        "all": "57100",
        "publicSector": "1369",
        "privateSector": "55731"
    },
    {
        "activity": "Операции с недвижими имоти",
        "all": "24287",
        "publicSector": "2660",
        "privateSector": "21627"
    },
    {
        "activity": "Професионални дейности и научни изследвания",
        "all": "81616",
        "publicSector": "9863",
        "privateSector": "71753"
    },
    {
        "activity": "Административни и спомагателни дейности",
        "all": "115768",
        "publicSector": "17160",
        "privateSector": "98608"
    },
    {
        "activity": "Държавно управление",
        "all": "111142",
        "publicSector": "x"
    },
    {
        "activity": "Образование",
        "all": "162463",
        "publicSector": "152576",
        "privateSector": "9887"
    },
    {
        "activity": "Хуманно здравеопазване и социална работа ",
        "all": "138923",
        "publicSector": "100522",
        "privateSector": "38401"
    },
    {
        "activity": "Култура,спорт и развлечения",
        "all": "37557",
        "publicSector": "14345",
        "privateSector": "23212"
    },
    {
        "activity": "Други дейности",
        "all": "37459",
        "publicSector": "1369",
        "privateSector": "36090"
    }
]